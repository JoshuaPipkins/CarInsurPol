def my_function(Driving):
 Customer_age = input ("Please tell us your age ")
 Premium_month = input("Please enter the month ")
 if Premium_month >= '12':
    Premium_month = '0' 
 Premium_day = input("Please enter the day ")
 if Premium_day <= '32':
    Premium_day = '0'
 Premium_year = input ("Please enter the year ")
 Driver_Accidents = int(Premium_month) - int(Premium_year) 
 print ("The number of car accidents this year is:", Driver_Accidents)




print("Welcome to the Drive-Rite Insurance Policy Calculator")
policy_number = input("Please enter a policy number ")
customer_lastname = input("Please enter your last name ")
customer_firstname = input("Please enter your first name ")
while (customer_firstname != 'ZZZZ'):
 my_function(customer_firstname)
 policy_number = input("To Exit Please Enter ZZZZ ")
 exit()

  



